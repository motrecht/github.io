
<!--============== head =========-->
<?php include 'includes/_head.php' ?>


<!--============== head =========-->
<?php include 'includes/_navbar.php' ?>



<!-- thumnail-blog is foto site -->


		
		<!-- Jumbotron, w title -->
		<div class="jumbotron text-center jumbotron-fluid">
			<div class="container">
				<h1>Statische website's</h1>
				
			</div>
		</div>

		<!-- Main container -->
		<div class="container">

			<!-- Latest blog posts -->
			<div class="row section">
				<div class="col-md-12">
					<h3>Alle Statische Website</h3>
				</div>
			</div>

			<!-- Alle statische website's hier onder. -->
			<div class="row">

			<!-- web 1 --> 
				<div class="col-md-4">
					<a href="website's/site1"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw1.jpg')"></div>
						<h5>Web 1</h5>
					</div></a>
				</div>
			<!-- einde 1 -->


			<!-- web 2 --> 
			<div class="col-md-4">
					<a href="website's/site2"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw2.jpg')"></div>
						<h5>Web 2</h5>
					</div></a>
				</div>
			<!-- einde 2 -->


			<!-- web 3 --> 
			<div class="col-md-4">
					<a href="website's/site3"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw3.jpg')"></div>
						<h5>Web 3</h5>
					</div></a>
				</div>
			<!-- einde 3 -->


			<!-- web 4 --> 
			<div class="col-md-4">
					<a href="website's/site4"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw4.jpg')"></div>
						<h5>Web 4</h5>
					</div></a>
				</div>
			<!-- einde 4 -->


			<!-- web 5 --> 
			<div class="col-md-4">
					<a href="website's/site5"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw5.jpg')"></div>
						<h5>Web 5</h5>
					</div></a>
				</div>
			<!-- einde 5 -->




			<!-- web 6 --> 
			<div class="col-md-4">
					<a href="website's/site6"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw6.jpg')"></div>
						<h5>Web 6</h5>
					</div></a>
				</div>
			<!-- einde 6 -->






			<!-- web 7 --> 
			<div class="col-md-4">
					<a href="website's/site7"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw7.jpg')"></div>
						<h5>Web 7</h5>
					</div></a>
				</div>
			<!-- einde 7 -->






			<!-- web 8 --> 
			<div class="col-md-4">
					<a href="website's/site8"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw8.jpg')"></div>
						<h5>Web 8</h5>
					</div></a>
				</div>
			<!-- einde 8 -->






			<!-- web 9 --> 
			<div class="col-md-4">
					<a href="website's/site9"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw9.jpg')"></div>
						<h5>Web 9</h5>
					</div></a>
				</div>
			<!-- einde 9 -->
				
				













			</div>

		</div>
		



		<!--============== head =========-->
<?php include 'includes/_footer.php' ?>
