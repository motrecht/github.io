
<!--============== head =========-->
<?php include 'includes/_head.php' ?>


<!--============== head =========-->
<?php include 'includes/_navbar.php' ?>



<!-- thumnail-blog is foto site -->


		
		<!-- Jumbotron, w title -->
		<div class="jumbotron text-center jumbotron-fluid">
			<div class="container">
				<h1>Neem Contact op Voor al je wensen.</h1>
			</div>
		</div>





        <div class="container">
			<div class="row section">

				<!-- The Contact form -->
				<!-- <div class="col-md-6">
					<div class="contact-form">
						<div class="form-group">
							<label>Name</label>
							<input type="text" class="form-control">
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="text" class="form-control">
						</div>
						<div class="form-group">
							<label>Message</label>
							<textarea class="form-control" rows="7"></textarea>
						</div>
						<input type="submit" class="btn btn-primary" value="Submit Button">
					</div>
				</div> -->

				<!-- Contact details -->
				<div class="col-md-6">
					<p>Stuur ons een bericht en we nemen zo snel mogelijk contact op met je.</p>

				
					<p><span class="font-weight-bold">Email:</span> <a href="mailto:info@mosupply.nl">info@mosupply.nl</a></p>
					

					<!--<p><span class="font-weight-bold">Phone (US):</span>  +1.206.445.0048</p> -->
				</div>
			</div>
		</div>






		<!--============== head =========-->
        <?php include 'includes/_footer.php' ?>
