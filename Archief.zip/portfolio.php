
<!--============== head =========-->
<?php include 'includes/_head.php' ?>


<!--============== head =========-->
<?php include 'includes/_navbar.php' ?>



<!-- thumnail-blog is foto site -->


		
		<!-- Jumbotron, w title -->
		<div class="jumbotron text-center jumbotron-fluid">
			<div class="container">
				<h1>Portfolio Template's</h1>
				
			</div>
		</div>

		<!-- Main container -->
		<div class="container">

			<!-- Latest blog posts -->
			<div class="row section">
				<div class="col-md-12">
					<h3>Alle Portfolio Website</h3>
				</div>
			</div>

			<!-- Alle statische website's hier onder. -->
			<div class="row">



			<!-- web 6 --> 
			<div class="col-md-4">
					<a href="website's/site6"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw6.jpg')"></div>
						<h5>Web 6 - Portfolio's</h5>
					</div></a>
				</div>
			<!-- einde 6 -->






			<!-- web 10 --> 
			<div class="col-md-4">
					<a href="website's/site10"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw10.jpg')"></div>
						<h5>Web 10 - Portfolio's</h5>
					</div></a>
				</div>
			<!-- einde 10 -->



			<!-- web 11 --> 
			<div class="col-md-4">
					<a href="website's/site11"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw11.jpg')"></div>
						<h5>Web 11 - Portfolio's</h5>
					</div></a>
				</div>
			<!-- einde 11 -->



			<!-- web 12 --> 
			<div class="col-md-4">
					<a href="website's/site12"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw12.jpg')"></div>
						<h5>Web 12 - Blog's</h5>
					</div></a>
				</div>
			<!-- einde 1 -->









			</div>

		</div>
		



		<!--============== head =========-->
<?php include 'includes/_footer.php' ?>
