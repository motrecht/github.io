
<!--============== head =========-->
<?php include 'includes/_head.php' ?>


<!--============== head =========-->
<?php include 'includes/_navbar.php' ?>



<!-- thumnail-blog is foto site -->


		
		<!-- Jumbotron, w title -->
		<div class="jumbotron text-center jumbotron-fluid">
			<div class="container">
				<h1>Bedrijven Template's </h1>

				<p class="head">Hier vindt je alle geschikte website's voor je bedrijf.</p>
			</div>
		</div>

		<!-- Main container -->
		<div class="container">

			<!-- Latest blog posts -->
			<div class="row section">
				<div class="col-md-12">
					<h3>Alle Bedrijven Website</h3>
				</div>
			</div>

			<!-- Alle statische website's hier onder. -->
			<div class="row">
 



			<!-- web 1 --> 
			<div class="col-md-4">
					<a href="website's/site1"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw1.jpg')"></div>
						<h5>Web 1 - Bedrijven</h5>

					</div></a>
				</div>
			<!-- einde 1 -->


			<!-- web 2 --> 
			<div class="col-md-4">
					<a href="website's/site2"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw2.jpg')"></div>
						<h5>Web 2 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 2 -->


			<!-- web 3 --> 
			<div class="col-md-4">
					<a href="website's/site3"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw3.jpg')"></div>
						<h5>Web 3 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 3 -->


			<!-- web 4 --> 
			<div class="col-md-4">
					<a href="website's/site4"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw4.jpg')"></div>
						<h5>Web 4 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 4 -->


			<!-- web 5 --> 
			<div class="col-md-4">
					<a href="website's/site5"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw5.jpg')"></div>
						<h5>Web 5 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 5 -->



			<!-- web 7 --> 
			<div class="col-md-4">
					<a href="website's/site7"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw7.jpg')"></div>
						<h5>Web 7 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 7 -->






			<!-- web 8 --> 
			<div class="col-md-4">
					<a href="website's/site8"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw8.jpg')"></div>
						<h5>Web 8 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 8 -->






			<!-- web 9 --> 
			<div class="col-md-4">
					<a href="website's/site9"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw9.jpg')"></div>
						<h5>Web 9 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 9 -->



			<!-- web 14 --> 
			<div class="col-md-4">
					<a href="website's/site14"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw14.jpg')"></div>
						<h5>Web 14 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 14 -->



			<!-- vul aan meet websittes  -->

			<!-- web 15 --> 
			<div class="col-md-4">
					<a href="website's/site15"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw15.jpg')"></div>
						<h5>Web 15 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 15 -->
			



			<!-- web 16 --> 
			<div class="col-md-4">
					<a href="website's/site16"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw16.jpg')"></div>
						<h5>Web 16 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 16 -->
			


			<!-- web 17 --> 
			<div class="col-md-4">
					<a href="website's/site17"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw17.jpg')"></div>
						<h5>Web 17 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 17 -->


			<!-- web 18 --> 
			<div class="col-md-4">
					<a href="website's/site18"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw18.jpg')"></div>
						<h5>Web 18 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 18 -->



			<!-- web 19 --> 
			<div class="col-md-4">
					<a href="website's/site19"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw19.jpg')"></div>
						<h5>Web 19 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 19 -->



			<!-- web 20 --> 
			<div class="col-md-4">
					<a href="website's/site20"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw20.jpg')"></div>
						<h5>Web 20 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 20 -->



			<!-- web 21 --> 
			<div class="col-md-4">
					<a href="website's/site21"><div class="thumbnail-blog">
						<div class="thumbnail-img" style="background-image:url('images/website/screenw21.jpg')"></div>
						<h5>Web 21 - Bedrijven</h5>
					</div></a>
				</div>
			<!-- einde 21 -->














			</div>

		</div>
		



		<!--============== head =========-->
<?php include 'includes/_footer.php' ?>
