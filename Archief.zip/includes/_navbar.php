<div class="container">
<nav>
    <div class="navbar">
      <i class='bx bx-menu'></i>
      <div class="logo"><a href="index.php">MoSupply</a></div>
      <div class="nav-links">
        <div class="sidebar-logo">
          <span class="logo-name">MoSupply.nl</span>
          <i class='bx bx-x' ></i>
        </div>
        <ul class="links">
          <li><a href="index.php">HOME</a></li>
          <!--<li>
            <a href="#">HTML & CSS</a>
            <i class='bx bxs-chevron-down htmlcss-arrow arrow  '></i>
            <ul class="htmlCss-sub-menu sub-menu">
              <li><a href="#">Web Design</a></li>
              <li><a href="#">Login Forms</a></li>
              <li><a href="#">Card Design</a></li>
              <li class="more">
                <span><a href="#">More</a>
                <i class='bx bxs-chevron-right arrow more-arrow'></i>
              </span>
                <ul class="more-sub-menu sub-menu">
                  <li><a href="#">Neumorphism</a></li>
                  <li><a href="#">Pre-loader</a></li>
                  <li><a href="#">Glassmorphism</a></li>
                </ul>
              </li>
            </ul>
          </li> -->
          <li>
            <a href="staticwebsite's.php">WEBSITE'S</a>
            <i class='bx bxs-chevron-down js-arrow arrow '></i>
            <ul class="js-sub-menu sub-menu">
              <li><a href="staticwebsite's.php">Alle Website's</a></li>
              <li><a href="bedrijven.php">Bedrijven</a></li>
              <li><a href="portfolio.php">portfolio's</a></li>
            </ul>
          </li>
          <li><a href="pricing.php">PRICING</a></li>
          <li><a href="contact.php">CONTACT</a></li>
        </ul>
      </div>


      <!-- translate gedeelte -->

      
      <div class="search-box">
        
        <div class="gtranslate_wrapper"></div>

      </div>

      <!-- einde translate gedeelte -->
      
    </div>
  </nav>

</div>

