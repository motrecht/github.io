
		<!-- Footer -->
		<div class="container-fluid footer">
			<div class="container">

				<div class="row section">
					<div class="col-md-4">
						<ul class="footer-links">
							<h5>statische Website's</h5>
							<li><a href="staticwebsite's.php">Bedrijven</a></li>
							<li><a href="portfolio.php">portfolio's</a></li>
							<li><a href="portfolio.php">Blog's</a></li>
						</ul>
					</div>

					<!--
					<div class="col-md-4">
						<ul class="footer-links">
							<h5>Dynamische Websites</h5>
							<li><a href="#">Bedrijven</a></li>
							<li><a href="#">portfolio's</a></li>
							<li><a href="#">Blog's</a></li>
							<li><a href="#">Verenegingen</a></li>
						</ul>
					</div> -->
					<div class="col-md-4 text-center">
						<ul class="footer-links">
							<h5>MoSupply</h5>
							<li><a href="contact.php">Contact</a></li>
						</ul>
					</div>
					<div class="text-center">
						<div class="logo"><a href="index.php">MoSupply.nl</a></div>
					</div>
				</div>

			</div>
		</div>




	
	<!-- Scripts -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

	<script src="https://cdn.gtranslate.net/widgets/latest/float.js" defer></script>

	<script src="js/script.js"></script>
	<script src="js/trans2.js"></script>
	
	</body>
</html>

